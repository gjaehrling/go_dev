package main

import (
	"fmt"

	"github.com/daixiang0/gci"
)

import "C"

import "github.com/golang"

import (
  "github.com/daixiang0/gci"
)
