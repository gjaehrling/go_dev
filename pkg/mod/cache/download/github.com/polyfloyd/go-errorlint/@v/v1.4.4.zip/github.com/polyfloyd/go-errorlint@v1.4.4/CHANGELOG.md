## v1.4.4 (2023-08-20)

### Fix

- Is methods should be exempt for type assertions and switches too (#50)
- add missing testdata
- ignore unix errno values

### Refactor

- pass extinfo to type assertions
- Permit matching on full paths of allowed errors

## v1.4.3 (2023-06-30)

### Fix

- ignore io.EOF from some more sources

## v1.4.2 (2023-05-12)

### Fix

- Allowed checker panics in some cases (fixes #42)

## v1.4.1 (2023-05-01)

### Fix

- Tar allowlist should be archive/tar

## v1.4.0 (2023-03-13)

### Feat

- Require Go 1.20 in go.mod

## v1.3.0 (2023-03-07)

### Feat

- Suggest fixes for missing wrap verbs
- Stop linting arguments that are .Error() expressions

## v1.2.0 (2023-02-25)

### Feat

- Add the -errorf-multi flag

## v1.1.0 (2023-02-10)

### Feat

- Look for multiple %w verbs as these are valid starting with Go 1.20

## v1.0.6 (2022-11-24)

## v1.0.5 (2022-09-29)

## v1.0.4 (2022-09-16)

## v1.0.3 (2022-09-09)

## v1.0.2 (2022-08-12)

## v1.0.1 (2022-08-11)

## v1.0.0 (2022-05-10)
