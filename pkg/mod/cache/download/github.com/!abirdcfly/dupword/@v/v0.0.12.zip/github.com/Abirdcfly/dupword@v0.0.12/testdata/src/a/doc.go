// Package a this comment include duplicated word and and // want `Duplicate words \(and\) found`
package a
