// baz baz qux
// qux foo

package fixtures // MATCH /the file doesn't have an appropriate header/
