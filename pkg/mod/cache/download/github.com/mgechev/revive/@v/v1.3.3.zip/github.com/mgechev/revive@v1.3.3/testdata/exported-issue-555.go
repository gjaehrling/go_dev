// Package golint comment
package golint

// Test case for disabling stuttering check in exported rule

//  GolintSomething is a dummy function
func GolintSomething() {}
