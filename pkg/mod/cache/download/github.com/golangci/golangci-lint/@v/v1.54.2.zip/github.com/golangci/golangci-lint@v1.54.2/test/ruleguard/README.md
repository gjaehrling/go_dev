This directory contains ruleguard files that are used in functional tests.
